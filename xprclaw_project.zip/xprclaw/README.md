# GCSC CLAW — xprclaw

**Self-Evolving AI Economic System on XPR Network**

Token: `$XLAW` · Network: XPR (Proton) · Audience: B2B Enterprises

---

## Quick Start

### 1. Open the app

Simply open `index.html` in a modern browser (Chrome, Firefox, Safari, Edge).
No build step required — the app is a zero-dependency SPA.

```bash
# From project root:
open index.html
# or
python -m http.server 8000   # then visit http://localhost:8000
```

### 2. Connect your wallet

Click **Connect Wallet** → choose WebAuth / Proton Wallet / Metal Pay.

### 3. Explore

- **Dashboard** — your agents, activity, balances
- **AI Secretary** — chat with your LDA/DAA/KYC/EFA/REA agents
- **Trading Bot** — monitor the day-trading bot (requires backend, see below)
- **Staking** — lock $XLAW for 12% APY
- **Skill Marketplace** — buy/sell reusable AI workflows

---

## Project Structure

```
xprclaw/
├── index.html                    # Main SPA entry
├── src/
│   ├── styles/main.css           # Complete dark-violet design system
│   ├── data/mockData.js          # Mock data (replace with real API calls)
│   ├── services/
│   │   ├── wallet.js             # XPR wallet connection
│   │   ├── chain.js              # Blockchain queries
│   │   └── tradingBot.js         # Trading bot API client
│   ├── pages/
│   │   ├── landing.js            # Hero + features
│   │   ├── dashboard.js          # User dashboard
│   │   ├── chat.js               # AI Secretary chat
│   │   ├── trading.js            # Trading bot UI
│   │   ├── staking.js            # Staking
│   │   └── marketplace.js        # Skill marketplace
│   └── main.js                   # SPA router
├── backend/
│   └── trading-bot/              # Python day-trading bot (separate service)
│       ├── main.py               # Orchestrator
│       ├── risk/risk_engine.py   # Risk gate
│       ├── strategies/           # Trend / Mean-Rev / Event-Driven modules
│       ├── data/                 # Exchange feeds + feature store
│       ├── execution/            # Order execution
│       └── requirements.txt
└── docs/                         # Documentation
```

---

## XPR Network Integration

The app is designed to integrate with XPR Network via `@proton/web-sdk`.
Currently wallet connection is simulated for MVP/demo.

To enable real XPR integration:

```bash
npm install @proton/web-sdk
```

Then in `src/services/wallet.js`, uncomment the real `ConnectWallet()` call.

**Deployed Contracts:**
- `gcsctoken111` — Main $XLAW token ✓ DEPLOYED
- `gcscmember11` — Membership tiers
- `gcscstake111` — Staking 12% APY
- `gcscrealty11` — Real Estate DAO
- `gcscinsure11` — Insurance
- `gcsctreasry1` — Treasury DAO

---

## Trading Bot Backend

The trading bot is a **separate Python service** that runs independently of the frontend.

### Architecture (10 layers)

1. **Data Layer** — WebSocket feeds from Binance/Bybit → Redis Streams
2. **Feature Store** — Deterministic features (technical + microstructure)
3. **Signal Layer** — ML models (LightGBM) for trend + mean-reversion + event-driven
4. **Regime Detector** — HMM classifier for trending / ranging / news-driven
5. **LLM Agents** — News + Context + Trade Reviewer (Claude/GPT as filters, not generators)
6. **Orchestrator** — Rule-based, not AI. Selects module by regime.
7. **Risk Engine** — Gate, not voter. Blocks or allows.
8. **Execution** — Market/limit orders with stop-loss on exchange
9. **Backtest** — Event-driven, walk-forward validation
10. **Observability** — PnL attribution, latency, fill rates

### Setup

```bash
cd backend/trading-bot
pip install -r requirements.txt
export EXCHANGE_API_KEY=your_key
export EXCHANGE_SECRET=your_secret
export ANTHROPIC_API_KEY=your_key
python main.py --mode=paper   # paper trading (shadow mode)
```

### Critical Warnings

**Before running with real capital:**
- 2 weeks of shadow trading minimum
- Walk-forward validation on out-of-sample data
- Backtest-to-live slippage sanity check
- Start with amount you are willing to lose completely

Expected edge on first iteration: **20-30%**.
Most edge comes from iterating on signal modules, not from AI architecture.

---

## Tokenomics

### $XLAW (Governance + Utility)
- Max Supply: 1,000,000,000
- Staking APY: 12% (30-day lock)
- Burn Rate: 60-80% per AI execution

### XUSDC (Stablecoin)
- Pegged to $1 USD
- Used for subscriptions, escrow, insurance

### Revenue Distribution
| Stream | Distribution |
|--------|-------------|
| Subscriptions | 30% stakers / 40% ops / 30% Treasury |
| Skill Sales | 60% burn / 20% creator / 20% system |
| Lead Token | 50% burn / 50% Treasury |
| Escrow Fee | 70% protocol / 20% Treasury / 10% buyback |

---

## Membership Tiers

| Tier | Price | Secretary NFTs | Entry Bonus |
|------|-------|----------------|-------------|
| ASSOCIATE | $49/mo | 1 | 50M $XLAW |
| COUNSEL | $99/mo | 3 | 150M $XLAW |
| PARTNER | $199/mo | 7 | 350M $XLAW |

---

## Contact

- Email: gcscdao@gmail.com
- GitHub: https://github.com/Melxisedek75/gcsc-website
- Network: XPR (Proton)

White Paper v1.0 — 2025
