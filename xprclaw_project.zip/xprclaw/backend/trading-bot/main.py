"""
════════════════════════════════════════════════════════════════
GCSC CLAW — Day Trading Bot
Architecture: 10-layer hybrid ML + LLM design

This is the MAIN ORCHESTRATOR. See architecture in docs/TRADING_BOT.md

Layers:
  1. Data Layer (WebSocket → Redis Streams)
  2. Feature Store (technical + microstructure + volatility)
  3. Signal Layer (Trend + Mean-Rev + Event-Driven, no LLM)
  4. Regime Detector (HMM)
  5. LLM Agents (News + Context + Trade Reviewer)
  6. Orchestrator (THIS FILE — rule-based, not AI)
  7. Risk Engine (gate, not voter)
  8. Execution
  9. Backtest & Validation
  10. Observability

Required env vars:
  EXCHANGE_API_KEY, EXCHANGE_SECRET
  ANTHROPIC_API_KEY (for LLM agents)
  REDIS_URL, TIMESCALE_URL

Run:
  python main.py --mode=paper   # shadow trading
  python main.py --mode=live    # real money (use with care)
  python main.py --mode=backtest --start=2024-01-01 --end=2024-06-30
════════════════════════════════════════════════════════════════
"""

import asyncio
import logging
from dataclasses import dataclass
from typing import Optional

# Local imports (skeletons in other files)
from data.exchange_feed import ExchangeFeed
from data.feature_store import FeatureStore
from strategies.trend_following import TrendFollowingModule
from strategies.mean_reversion import MeanReversionModule
from strategies.event_driven import EventDrivenModule
from strategies.regime_detector import RegimeDetector
from strategies.llm_agents import NewsAnalyst, ContextAnalyst, TradeReviewer
from risk.risk_engine import RiskEngine
from execution.executor import Executor
from observability.metrics import MetricsCollector

logging.basicConfig(level=logging.INFO, format='%(asctime)s [%(levelname)s] %(message)s')
log = logging.getLogger('orchestrator')


@dataclass
class Signal:
    direction: str           # 'long' | 'short' | 'flat'
    strength: float          # 0.0 - 1.0 (calibrated probability)
    horizon_minutes: int     # how long to hold
    invalidation_level: float  # price at which signal is wrong
    source_module: str


class Orchestrator:
    """
    Layer 6: Rule-based orchestrator.
    Collects inputs from all other layers and decides whether to trade.
    CRITICAL: no AI here. AI goes into filter gates, not decision logic.
    """

    def __init__(self, config: dict):
        self.config = config
        self.feed = ExchangeFeed(config['exchange'])
        self.features = FeatureStore()
        self.regime_detector = RegimeDetector()
        self.trend_mod = TrendFollowingModule(self.features)
        self.mean_rev_mod = MeanReversionModule(self.features)
        self.event_mod = EventDrivenModule(self.features)
        self.news_agent = NewsAnalyst()
        self.context_agent = ContextAnalyst()
        self.reviewer = TradeReviewer()
        self.risk_engine = RiskEngine(config['risk'])
        self.executor = Executor(self.feed)
        self.metrics = MetricsCollector()

        # Thresholds calibrated per regime from walk-forward validation
        self.thresholds = {
            'trending': 0.65,
            'ranging': 0.70,
            'news-driven': 0.60,
            'high-vol': 0.75,
            'low-vol': 0.72,
        }

    async def run(self):
        """Main trading loop."""
        log.info('Starting orchestrator...')
        await self.feed.connect()

        async for tick in self.feed.subscribe_ticks():
            try:
                await self._process_tick(tick)
            except Exception as e:
                log.error(f'Tick processing failed: {e}', exc_info=True)

    async def _process_tick(self, tick):
        # 1. Update feature store (deterministic, same in live + backtest)
        self.features.update(tick)

        # 2. Detect current regime (15m-1h timeframe, updates every few minutes)
        regime = self.regime_detector.get_current_regime()

        # 3. Select signal module based on regime
        signal = self._select_signal(regime)
        if signal is None or signal.direction == 'flat':
            return

        # 4. Check signal strength threshold (per-regime)
        if signal.strength < self.thresholds[regime]:
            log.debug(f'Signal strength {signal.strength:.2f} below threshold for {regime}')
            return

        # 5. Context agent filter (LLM, slow: every 5-15 min)
        context = self.context_agent.get_current_context()
        if context.flags_risk:
            log.info(f'Context agent flagged risk: {context.reasoning}')
            return

        # 6. Risk engine gate (BLOCKS, does not vote)
        portfolio = self.executor.get_portfolio()
        risk_result = self.risk_engine.check(signal, portfolio)
        if not risk_result.allowed:
            log.info(f'Risk engine blocked: {risk_result.reason}')
            self.metrics.record_risk_block(risk_result.reason)
            return

        # 7. Execute (deterministic, no AI)
        position_size = self.risk_engine.position_size(signal, portfolio)
        await self.executor.place_order(signal, position_size)
        log.info(f'Order placed: {signal.direction} {signal.source_module} strength={signal.strength:.2f}')
        self.metrics.record_signal(signal, regime)

    def _select_signal(self, regime: str) -> Optional[Signal]:
        """Rule-based module selection."""
        if regime == 'news-driven':
            news = self.news_agent.get_latest_impact()
            if news and news.impact == 'high':
                return self.event_mod.get_signal(news)
            return None
        elif regime == 'trending':
            return self.trend_mod.get_signal()
        elif regime == 'ranging':
            return self.mean_rev_mod.get_signal()
        else:
            return None  # no-trade regime (high-vol without clear direction)


async def main():
    import argparse
    parser = argparse.ArgumentParser()
    parser.add_argument('--mode', choices=['paper','live','backtest'], default='paper')
    parser.add_argument('--start', help='Backtest start date YYYY-MM-DD')
    parser.add_argument('--end',   help='Backtest end date YYYY-MM-DD')
    args = parser.parse_args()

    config = {
        'exchange': 'binance',
        'mode': args.mode,
        'risk': {
            'daily_loss_limit_pct': 2.0,
            'max_concurrent_positions': 5,
            'kelly_fraction': 0.25,
            'correlation_limit': 3,
        },
    }

    if args.mode == 'backtest':
        from data.backtest_engine import EventDrivenBacktester
        bt = EventDrivenBacktester(config)
        results = await bt.run(start=args.start, end=args.end)
        print(results.summary())
    else:
        orch = Orchestrator(config)
        await orch.run()


if __name__ == '__main__':
    asyncio.run(main())
