"""
Layer 7: Risk Engine
CRITICAL PRINCIPLE: Risk is a GATE, not a voter.
Never add risk score to signal score. Always block-or-allow.
"""

from dataclasses import dataclass
from typing import Optional


@dataclass
class RiskCheckResult:
    allowed: bool
    reason: Optional[str] = None


class RiskEngine:
    def __init__(self, config: dict):
        self.daily_loss_limit_pct = config['daily_loss_limit_pct']
        self.max_concurrent = config['max_concurrent_positions']
        self.kelly_fraction = config['kelly_fraction']
        self.correlation_limit = config['correlation_limit']

        self.day_pnl_pct = 0.0
        self.kill_switch_triggered = False

    def check(self, signal, portfolio) -> RiskCheckResult:
        """Pre-trade checks. All must pass for order to be allowed."""

        # Kill switch
        if self.kill_switch_triggered:
            return RiskCheckResult(False, 'Kill switch armed - halt all trading')

        # Daily loss limit
        if self.day_pnl_pct <= -self.daily_loss_limit_pct:
            self.kill_switch_triggered = True
            return RiskCheckResult(False, f'Daily loss limit hit: {self.day_pnl_pct:.2f}%')

        # Max concurrent positions
        if len(portfolio.positions) >= self.max_concurrent:
            return RiskCheckResult(False, f'Max {self.max_concurrent} concurrent positions')

        # Correlation limit (e.g. no 5 long positions in correlated assets)
        same_direction = sum(1 for p in portfolio.positions if p.direction == signal.direction)
        if same_direction >= self.correlation_limit:
            return RiskCheckResult(False, f'Correlation limit: {same_direction} positions same direction')

        # Macro event blackout (if implemented)
        # if self.is_near_macro_event():
        #     return RiskCheckResult(False, 'Within macro event blackout window')

        return RiskCheckResult(True)

    def position_size(self, signal, portfolio) -> float:
        """
        Volatility-adjusted Kelly sizing.
        Size inversely proportional to ATR. Quarter-Kelly for drawdown protection.
        """
        # Simplified: in production, use calibrated probability + ATR
        edge = signal.strength - 0.5  # assumes calibrated
        if edge <= 0:
            return 0.0

        kelly_full = edge / (signal.strength * (1 - signal.strength))
        kelly_adjusted = kelly_full * self.kelly_fraction

        # Cap at 10% of equity per position
        return min(kelly_adjusted, 0.10) * portfolio.equity
