// ═══════════════════════════════════════════════════════════════
// GCSC CLAW · Main App
// SPA router + global handlers
// ═══════════════════════════════════════════════════════════════

let currentPage = 'landing';
let currentCleanup = null;

// ─── ROUTER ──────────────────────────────────────────────────────
window.navigate = function(page) {
  // Cleanup previous page
  if (currentCleanup && typeof currentCleanup === 'function') {
    try { currentCleanup(); } catch(e) { console.warn(e); }
  }

  // Render new page
  const app = document.getElementById('app');
  const renderFn = window.Pages[page];
  if (!renderFn) {
    console.error('Page not found:', page);
    return;
  }

  app.innerHTML = renderFn();
  currentPage = page;

  // Update active nav
  document.querySelectorAll('.nav-links a').forEach(a => {
    a.classList.toggle('active', a.dataset.page === page);
  });

  // Close mobile nav
  document.getElementById('navLinks').classList.remove('open');

  // Init page
  const initFn = window.Pages[page + 'Init'];
  if (initFn && typeof initFn === 'function') {
    try { initFn(); } catch(e) { console.error(e); }
  }

  // Store cleanup
  currentCleanup = window.Pages[page + 'Cleanup'];

  // Scroll to top
  window.scrollTo({ top: 0, behavior: 'smooth' });

  // Update URL hash (optional, for bookmarks)
  history.replaceState(null, '', '#' + page);
};

window.scrollToId = function(id) {
  document.getElementById(id)?.scrollIntoView({ behavior: 'smooth' });
};

// ─── MODALS ──────────────────────────────────────────────────────
window.openConnectModal = function() {
  document.getElementById('connectModal').classList.add('open');
};
window.openDeployModal = function() {
  if (!WalletService.getState().connected) {
    showToast('Wallet Required', 'Please connect your XPR wallet first.');
    openConnectModal();
    return;
  }
  document.getElementById('deployModal').classList.add('open');
};
window.closeModal = function(id) {
  document.getElementById(id).classList.remove('open');
};
window.closeOnOverlay = function(e, id) {
  if (e.target.id === id) closeModal(id);
};

// ─── WALLET ──────────────────────────────────────────────────────
window.connectWallet = async function(name) {
  closeModal('connectModal');
  showToast('Connecting…', 'Establishing secure connection to XPR Network…');
  try {
    await WalletService.connect(name);
    const btn = document.getElementById('connectBtn');
    btn.textContent = '● ' + MockData.user.wallet;
    btn.classList.add('connected');
    updateBalanceDisplay();
    showToast('✓ Wallet Connected', name + ' connected to XPR Network. Welcome to GCSC CLAW.');
  } catch(e) {
    showToast('Connection Failed', e.message);
  }
};

window.updateBalanceDisplay = function() {
  const bal = document.getElementById('walletBalance');
  const amt = bal?.querySelector('.bal-amount');
  if (WalletService.getState().connected) {
    if (bal) bal.style.display = 'flex';
    if (amt) amt.textContent = MockData.user.xlawBalance.toLocaleString();
  } else {
    if (bal) bal.style.display = 'none';
  }
};

// ─── DEPLOY AGENT ────────────────────────────────────────────────
window.deployAgent = async function() {
  const name = document.getElementById('agentName').value.trim();
  const wallet = document.getElementById('agentWallet').value.trim();
  const tier = document.getElementById('agentTier').value;
  const use = document.getElementById('agentUse').value;
  if (!name) { showToast('Missing Field', 'Please enter an agent name.'); return; }
  if (!wallet) { showToast('Missing Field', 'Please enter your XPR wallet address.'); return; }
  closeModal('deployModal');
  showToast('Deploying…', 'Submitting transaction to XPR Network (gcscmember11)…');
  try {
    const tx = await WalletService.sign('deploy_agent', { name, use_case: use, tier, wallet });
    showToast('🚀 Agent Deployed!', `"${name}" is live on XPR Network. Tier: ${tier.split('—')[0].trim()}. +15 $XLAW credit applied. Tx: ${tx.txId.slice(0,10)}...`);
    // Add to mock data
    MockData.agents.unshift({
      id: 'a' + Date.now(),
      name,
      type: tier.includes('PARTNER') ? 'ALL' : 'LDA',
      status: 'active',
      lastRun: 'just now',
      skills: 0,
      executions: 0,
    });
  } catch(e) {
    showToast('Deploy Failed', e.message);
  }
};

window.deployTier = function(tier, price) {
  if (!WalletService.getState().connected) {
    showToast('Wallet Required', 'Please connect your XPR wallet first.');
    openConnectModal();
    return;
  }
  document.getElementById('agentTier').value = `${tier} — $${price}/mo`;
  openDeployModal();
};

// ─── TOAST ───────────────────────────────────────────────────────
let toastTimer;
window.showToast = function(title, msg) {
  const t = document.getElementById('toast');
  document.getElementById('toastTitle').textContent = title;
  document.getElementById('toastMsg').textContent = msg;
  t.classList.add('show');
  clearTimeout(toastTimer);
  toastTimer = setTimeout(() => t.classList.remove('show'), 4000);
};

// ─── MOBILE NAV ──────────────────────────────────────────────────
window.toggleMobileNav = function() {
  document.getElementById('navLinks').classList.toggle('open');
};

// ─── KEYBOARD ────────────────────────────────────────────────────
document.addEventListener('keydown', e => {
  if (e.key === 'Escape') {
    ['connectModal', 'deployModal', 'stakeModal', 'skillModal'].forEach(closeModal);
  }
});

// ─── FOOTER BLOCK TICKER ─────────────────────────────────────────
setInterval(() => {
  const el = document.getElementById('footBlock');
  if (el) el.textContent = ChainService.getBlockHeight().toLocaleString();
}, 3000);

// ─── INITIAL RENDER ──────────────────────────────────────────────
document.addEventListener('DOMContentLoaded', () => {
  const hash = window.location.hash.slice(1);
  const validPages = ['landing','dashboard','chat','trading','staking','marketplace'];
  const initialPage = validPages.includes(hash) ? hash : 'landing';
  navigate(initialPage);
});

// Also init on window load for safety
if (document.readyState === 'loading') {
  // Will fire DOMContentLoaded
} else {
  // Already loaded
  setTimeout(() => navigate('landing'), 50);
}
