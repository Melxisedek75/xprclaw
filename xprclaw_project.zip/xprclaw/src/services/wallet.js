// ═══════════════════════════════════════════════════════════════
// Wallet Service — XPR Network Integration
// 
// In production, uses @proton/web-sdk for real wallet connection.
// For MVP/demo, we simulate the connection flow.
// 
// To enable real XPR:
//   npm install @proton/web-sdk
//   import { ConnectWallet } from '@proton/web-sdk';
// ═══════════════════════════════════════════════════════════════

window.WalletService = (function() {

  const STATE = {
    connected: false,
    wallet: null,
    address: null,
    balance: 0,
  };

  const listeners = [];

  function onChange(fn) { listeners.push(fn); }
  function emit() { listeners.forEach(fn => fn(STATE)); }

  /**
   * Connect wallet (WebAuth, Proton Wallet, Metal Pay)
   * Production: uses @proton/web-sdk ConnectWallet()
   */
  async function connect(walletName) {
    // Simulate XPR Network connection flow
    // In production this would be:
    //
    //   const { session, link } = await ConnectWallet({
    //     linkOptions: {
    //       endpoints: ['https://proton.eosusa.io'],
    //       chainId: '384da888112027f0321850a169f737c33e53b388aad48b5adace4bab97f437e0',
    //     },
    //     transportOptions: { requestAccount: 'gcsctoken111' },
    //     selectorOptions: { appName: 'GCSC CLAW' },
    //   });

    return new Promise((resolve) => {
      setTimeout(() => {
        STATE.connected = true;
        STATE.wallet = walletName;
        STATE.address = MockData.user.wallet;
        STATE.balance = MockData.user.xlawBalance;
        emit();
        resolve(STATE);
      }, 1500);
    });
  }

  function disconnect() {
    STATE.connected = false;
    STATE.wallet = null;
    STATE.address = null;
    STATE.balance = 0;
    emit();
  }

  function getState() { return { ...STATE }; }

  /**
   * Sign a transaction (deploy agent, stake, purchase skill)
   * Production: uses session.transact() from @proton/web-sdk
   */
  async function sign(action, data) {
    if (!STATE.connected) throw new Error('Wallet not connected');

    // In production:
    //
    //   const result = await session.transact({
    //     actions: [{
    //       account: 'gcsctoken111',
    //       name: action,
    //       authorization: [{ actor: STATE.address, permission: 'active' }],
    //       data: data,
    //     }]
    //   }, { blocksBehind: 3, expireSeconds: 30 });

    return new Promise((resolve) => {
      setTimeout(() => {
        resolve({
          txId: '0x' + Array(16).fill(0).map(() => Math.floor(Math.random()*16).toString(16)).join(''),
          blockNum: 47283900 + Math.floor(Math.random()*100),
          status: 'executed',
          action,
          data,
        });
      }, 1800);
    });
  }

  return { connect, disconnect, sign, getState, onChange };
})();
