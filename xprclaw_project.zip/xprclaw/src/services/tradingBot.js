// ═══════════════════════════════════════════════════════════════
// Trading Bot Service
//
// In production, connects to the Python backend via REST + WebSocket.
// See: backend/trading-bot/ for the architecture.
//
// Endpoints:
//   GET  /api/bot/status         — bot state + metrics
//   GET  /api/bot/positions      — open positions
//   GET  /api/bot/signals        — recent signals (LLM + ML output)
//   POST /api/bot/start          — start trading
//   POST /api/bot/pause          — pause (close nothing)
//   POST /api/bot/stop           — emergency stop (close all)
//   WS   /ws/bot                 — live price + signal stream
//
// For MVP, we use mock data and simulate live updates.
// ═══════════════════════════════════════════════════════════════

window.TradingBotService = (function() {

  const API_BASE = '/api/bot'; // production: https://api.xprclaw.com/bot
  let state = JSON.parse(JSON.stringify(MockData.trading));
  const listeners = [];

  function onUpdate(fn) { listeners.push(fn); }
  function emit() { listeners.forEach(fn => fn(state)); }

  async function getStatus() {
    // Production: return fetch(`${API_BASE}/status`).then(r => r.json());
    return Promise.resolve({ ...state });
  }

  async function start() {
    state.status = 'running';
    emit();
    return { ok: true };
  }

  async function pause() {
    state.status = 'paused';
    emit();
    return { ok: true };
  }

  async function stop() {
    state.status = 'stopped';
    state.openPositions = [];
    emit();
    return { ok: true };
  }

  async function closePosition(pair) {
    state.openPositions = state.openPositions.filter(p => p.pair !== pair);
    emit();
    return { ok: true };
  }

  // Simulates live price tick (as if WebSocket feed)
  function startLiveFeed() {
    setInterval(() => {
      if (state.status !== 'running') return;

      // Update price history
      const last = state.priceHistory[state.priceHistory.length - 1];
      const next = Math.round(last + (Math.random() - 0.48) * 150);
      state.priceHistory.push(next);
      if (state.priceHistory.length > 60) state.priceHistory.shift();

      // Update positions' current price + pnl
      state.openPositions.forEach(p => {
        const change = (Math.random() - 0.5) * 0.003;
        p.current = Math.round(p.current * (1 + change) * 100) / 100;
        const multiplier = p.side === 'long' ? 1 : -1;
        p.pnlPct = Math.round(((p.current - p.entry) / p.entry) * 100 * multiplier * 100) / 100;
        p.pnl = Math.round(p.pnlPct * p.entry * p.size / 100 * 100) / 100;
      });

      // Update equity
      const totalPnl = state.openPositions.reduce((s, p) => s + p.pnl, 0);
      state.equity = Math.round((state.balance + totalPnl) * 100) / 100;
      state.dayPnl = Math.round((state.equity - state.balance) * 100) / 100;

      emit();
    }, 2500);
  }

  // Occasionally inject new signals (simulates LLM + ML pipeline output)
  function startSignalSimulator() {
    setInterval(() => {
      if (state.status !== 'running') return;
      if (Math.random() > 0.7) return; // 30% chance per cycle

      const pairs = ['BTC/USDT','ETH/USDT','SOL/USDT','DOGE/USDT','LINK/USDT'];
      const types = ['buy','sell','hold'];
      const bodies = [
        'Trend module: breakout confirmed. Calibrated strength 0.72.',
        'Regime: trending. Context agent: no risk flags.',
        'Mean-reversion: RSI extreme. Exit signal. Strength 0.65.',
        'News agent: bullish announcement detected. Event-driven entry.',
        'Risk engine: correlation limit reached. No new trades.',
        'Shadow trading: signal matches backtest expectations.',
      ];

      state.recentSignals.unshift({
        type: types[Math.floor(Math.random()*3)],
        pair: pairs[Math.floor(Math.random()*pairs.length)],
        time: 'just now',
        body: bodies[Math.floor(Math.random()*bodies.length)],
      });
      if (state.recentSignals.length > 12) state.recentSignals.pop();

      emit();
    }, 8000);
  }

  return {
    getStatus, start, pause, stop, closePosition,
    onUpdate, startLiveFeed, startSignalSimulator,
  };
})();
