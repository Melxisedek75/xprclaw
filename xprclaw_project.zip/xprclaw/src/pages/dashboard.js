// ═══════════════ DASHBOARD PAGE ═══════════════
window.Pages = window.Pages || {};

window.Pages.dashboard = function() {
  const u = MockData.user;

  const statsHtml = `
    <div class="dash-grid">
      <div class="dash-card">
        <div class="dash-card-label">$XLAW BALANCE</div>
        <div class="dash-card-value accent">${u.xlawBalance.toLocaleString()}</div>
        <div class="dash-card-trend trend-up">▲ +120 (24h)</div>
      </div>
      <div class="dash-card">
        <div class="dash-card-label">STAKED</div>
        <div class="dash-card-value">${u.stakedAmount.toLocaleString()}</div>
        <div class="dash-card-trend">12% APY · earning +1.64 $XLAW/day</div>
      </div>
      <div class="dash-card">
        <div class="dash-card-label">REPUTATION</div>
        <div class="dash-card-value mint">${u.reputation}<span style="font-size:1rem;color:var(--muted);">/100</span></div>
        <div class="dash-card-trend trend-up">▲ +3 this week</div>
      </div>
      <div class="dash-card">
        <div class="dash-card-label">TIER</div>
        <div class="dash-card-value" style="font-size:1.6rem;">${u.tier}</div>
        <div class="dash-card-trend">Member since ${new Date(u.memberSince).toLocaleDateString('en-US',{month:'short',year:'numeric'})}</div>
      </div>
    </div>
  `;

  const activityHtml = MockData.activity.map(a => `
    <div class="activity-item">
      <div class="activity-icon">${a.icon}</div>
      <div class="activity-main">
        <div class="activity-title">${a.title}</div>
        <div class="activity-meta">${a.meta}</div>
      </div>
      <div class="activity-value ${a.type==='spend'?'neg':''}">${a.value} $XLAW</div>
    </div>
  `).join('');

  const agentsHtml = MockData.agents.map(a => `
    <div class="agent-box" onclick="navigate('chat')">
      <div class="agent-avatar">${a.type}</div>
      <div class="agent-box-info">
        <div class="agent-box-name">${a.name}</div>
        <div class="agent-box-status ${a.status==='active'?'':'idle'}">● ${a.status} · ${a.executions} executions</div>
      </div>
    </div>
  `).join('');

  return `
<div class="page dash-page">
  <div class="dash-header">
    <div class="dash-greeting">
      <h1>Welcome back, ${u.name}</h1>
      <p>Wallet: ${u.wallet} · Here's what's happening on your account</p>
    </div>
    <div class="dash-actions">
      <button class="btn-secondary btn-sm" onclick="navigate('staking')">Stake $XLAW</button>
      <button class="btn-primary btn-sm" onclick="openDeployModal()">Deploy Agent</button>
    </div>
  </div>

  ${statsHtml}

  <div class="dash-row">
    <div class="dash-panel">
      <div class="dash-panel-header">
        <div>
          <div class="dash-panel-title">$XLAW Balance (30 days)</div>
          <div class="dash-panel-sub">Accrued via staking + skill sales</div>
        </div>
        <button class="btn-secondary btn-sm" onclick="navigate('staking')">Manage</button>
      </div>
      <div class="chart-wrap">
        ${buildChart()}
      </div>
    </div>
    <div class="dash-panel">
      <div class="dash-panel-header">
        <div class="dash-panel-title">Recent Activity</div>
      </div>
      <div class="activity-list">
        ${activityHtml}
      </div>
    </div>
  </div>

  <div class="dash-panel">
    <div class="dash-panel-header">
      <div>
        <div class="dash-panel-title">Your AI Agents</div>
        <div class="dash-panel-sub">Tap to chat with any agent</div>
      </div>
      <button class="btn-primary btn-sm" onclick="openDeployModal()">+ New Agent</button>
    </div>
    <div class="agents-row">${agentsHtml}</div>
  </div>
</div>
  `;
};

function buildChart() {
  // Generate equity curve chart (SVG-based)
  const data = [];
  let v = 10000;
  for (let i = 0; i < 30; i++) {
    v += (Math.random() - 0.35) * 120;
    data.push(v);
  }
  const min = Math.min(...data);
  const max = Math.max(...data);
  const range = max - min;
  const w = 100, h = 100;
  const pts = data.map((d, i) => {
    const x = (i / (data.length - 1)) * w;
    const y = h - ((d - min) / range) * (h - 10) - 5;
    return `${x.toFixed(1)},${y.toFixed(1)}`;
  }).join(' ');
  const areaPts = `0,${h} ${pts} ${w},${h}`;

  return `
    <svg class="chart-svg" viewBox="0 0 100 100" preserveAspectRatio="none">
      <defs>
        <linearGradient id="chartGrad" x1="0" x2="1">
          <stop offset="0%" stop-color="#8b5cf6"/>
          <stop offset="100%" stop-color="#e879f9"/>
        </linearGradient>
        <linearGradient id="areaGrad" x1="0" y1="0" x2="0" y2="1">
          <stop offset="0%" stop-color="#8b5cf6" stop-opacity=".5"/>
          <stop offset="100%" stop-color="#8b5cf6" stop-opacity="0"/>
        </linearGradient>
      </defs>
      <line class="chart-grid" x1="0" y1="25" x2="100" y2="25"/>
      <line class="chart-grid" x1="0" y1="50" x2="100" y2="50"/>
      <line class="chart-grid" x1="0" y1="75" x2="100" y2="75"/>
      <polygon class="chart-area" points="${areaPts}"/>
      <polyline class="chart-line" points="${pts}"/>
    </svg>
  `;
}

window.Pages.dashboardInit = function() {};
window.Pages.dashboardCleanup = function() {};
