// ═══════════════ LANDING PAGE ═══════════════
window.Pages = window.Pages || {};
window.Pages.landing = function() {
  return `
<div class="page">

  <!-- HERO -->
  <section class="hero">
    <div class="hero-badge">
      <span class="badge-dot"></span>
      LIVE ON XPR NETWORK · TESTNET ACTIVE
    </div>
    <div class="hero-title">
      <span class="line1">Deploy Your</span>
      <span class="line2">GCSCClaw.</span>
    </div>
    <p class="hero-sub">
      Pre-trained on <strong>XPR Network</strong> and 10+ ecosystems — skip the trial and error.
      <strong>Private AI agents</strong>, no rate limits.
      Pay as you go. <strong>Gets smarter every session.</strong>
    </p>
    <div class="hero-price-card">
      <div class="price-row">
        <div class="xpr-icon">XPR</div>
        <div class="price-amount">20 $XLAW</div>
      </div>
      <div class="price-note">private cloud agent + 15 $XLAW credit</div>
    </div>
    <div class="hero-actions">
      <button class="btn-primary" onclick="openDeployModal()">Deploy Your Agent</button>
      <button class="btn-secondary" onclick="scrollToId('how')">See How It Works</button>
    </div>
  </section>

  <!-- STATS -->
  <div class="stats-bar">
    <div class="stat-item"><div class="stat-num" id="statAgents">0</div><div class="stat-label">AGENTS DEPLOYED</div></div>
    <div class="stat-item"><div class="stat-num" id="statSkills">0</div><div class="stat-label">SKILLS CREATED</div></div>
    <div class="stat-item"><div class="stat-num" id="statBurned">0</div><div class="stat-label">$XLAW BURNED</div></div>
    <div class="stat-item"><div class="stat-num" id="statBlock">—</div><div class="stat-label">XPR BLOCK HEIGHT</div></div>
  </div>

  <!-- HOW IT WORKS -->
  <section id="how">
    <div class="container">
      <span class="section-tag reveal">How it works</span>
      <h2 class="section-title reveal">Self-Evolving AI <span>Economic Loop</span></h2>
      <p class="section-sub reveal">Every AI execution generates a reusable skill. Every skill reduces cost. Every cost reduction attracts more usage. The loop never stops.</p>
      <div class="grid-3">
        <div class="card reveal"><div class="card-num">STEP 01</div><div class="card-icon">⚡</div><div class="card-title">Request Execution</div><div class="card-desc">Send any business task — contract generation, cost estimation, risk analysis. The CLAW orchestrator routes it instantly.</div></div>
        <div class="card reveal"><div class="card-num">STEP 02</div><div class="card-icon">🧠</div><div class="card-title">Memory & Learning</div><div class="card-desc">Every interaction stored in 3-layer memory (Session + SQLite + Qdrant). Patterns are detected automatically.</div></div>
        <div class="card reveal"><div class="card-num">STEP 03</div><div class="card-icon">🔧</div><div class="card-title">Skill Auto-Creation</div><div class="card-desc">After 3+ similar tasks, the platform packages the workflow into a reusable skill — 10x cheaper to execute.</div></div>
        <div class="card reveal"><div class="card-num">STEP 04</div><div class="card-icon">🔥</div><div class="card-title">Token Burn</div><div class="card-desc">60–80% of every $XLAW spent is burned permanently. More usage = more scarcity = organic price appreciation.</div></div>
        <div class="card reveal"><div class="card-num">STEP 05</div><div class="card-icon">🏪</div><div class="card-title">Skill Marketplace</div><div class="card-desc">Publish your skills. Earn 20% of every purchase. The other 60% is burned, 20% goes to the system.</div></div>
        <div class="card reveal"><div class="card-num">STEP 06</div><div class="card-icon">🔄</div><div class="card-title">Repeat & Scale</div><div class="card-desc">The system improves itself. You own the value you create. No central control. No rate limits.</div></div>
      </div>
    </div>
  </section>

  <!-- AGENTS -->
  <section id="agents" style="background:var(--bg2);">
    <div class="container">
      <span class="section-tag reveal">AI Agents</span>
      <h2 class="section-title reveal">Five Specialized <span>AI Agents</span></h2>
      <p class="section-sub reveal">Your Secretary NFT interfaces all five agents. One conversation — five capabilities. Always on, always learning.</p>
      <div class="grid-4">
        <div class="agent-card reveal"><div class="agent-abbr">LDA</div><div class="agent-name">Legal Document Agent</div><div class="agent-desc">Generates and analyzes contracts. NLP + template engine.</div></div>
        <div class="agent-card reveal"><div class="agent-abbr">DAA</div><div class="agent-name">Dispute Arbitration Agent</div><div class="agent-desc">DAO-based dispute resolution. Multi-sig + voting.</div></div>
        <div class="agent-card reveal"><div class="agent-abbr">KYC-A</div><div class="agent-name">Identity & Compliance</div><div class="agent-desc">WebAuth + biometric + NFC. License verification.</div></div>
        <div class="agent-card reveal"><div class="agent-abbr">EFA</div><div class="agent-name">Escrow & Fund Agent</div><div class="agent-desc">Smart contract escrow for every deal. 0.5–2% fee.</div></div>
        <div class="agent-card reveal"><div class="agent-abbr">REA</div><div class="agent-name">Regulatory Enforcement</div><div class="agent-desc">Monitors legal changes. Web scraping + NLP.</div></div>
      </div>
    </div>
  </section>

  <!-- TOKENOMICS -->
  <section id="tokenomics">
    <div class="container">
      <span class="section-tag reveal">Token Economy</span>
      <h2 class="section-title reveal">$XLAW <span>Tokenomics</span></h2>
      <p class="section-sub reveal">Two-token system. Real utility-driven burn. Every execution reduces supply.</p>
      <div class="token-grid">
        <div class="token-card reveal">
          <div class="token-card-title">$XLAW Token</div>
          <div class="token-card-sub">Governance + Utility — XPR Network</div>
          <div class="token-rows">
            <div class="token-row"><span class="token-row-label">Max Supply</span><span class="token-row-val">1,000,000,000</span></div>
            <div class="token-row"><span class="token-row-label">Staking APY</span><span class="token-row-val">12%</span></div>
            <div class="token-row"><span class="token-row-label">Lock Period</span><span class="token-row-val">30 Days</span></div>
            <div class="token-row"><span class="token-row-label">Burn Rate</span><span class="token-row-val">60–80% per call</span></div>
            <div class="token-row"><span class="token-row-label">Deployed</span><span class="token-row-val">gcsctoken111</span></div>
          </div>
          <div class="burn-bar"><div class="burn-fill"></div></div>
          <div style="font-size:.72rem;color:var(--muted);margin-top:6px;font-family:var(--f-mono);">70% BURN RATE ACTIVE</div>
        </div>
        <div class="token-card reveal">
          <div class="token-card-title">Revenue Distribution</div>
          <div class="token-card-sub">Per transaction type on XPR Network</div>
          <div class="token-rows">
            <div class="token-row"><span class="token-row-label">Subscriptions</span><span class="token-row-val">30% Stakers / 40% Ops</span></div>
            <div class="token-row"><span class="token-row-label">Skill Sales</span><span class="token-row-val">60% Burn / 20% Creator</span></div>
            <div class="token-row"><span class="token-row-label">Lead Token</span><span class="token-row-val">50% Burn / 50% Treasury</span></div>
            <div class="token-row"><span class="token-row-label">Escrow Fee</span><span class="token-row-val">70% Protocol / 20% DAO</span></div>
            <div class="token-row"><span class="token-row-label">Insurance</span><span class="token-row-val">60% Reserve / 30% Stakers</span></div>
          </div>
          <div style="margin-top:14px;padding:10px;background:rgba(52,211,153,0.06);border:1px solid rgba(52,211,153,0.2);border-radius:10px;font-size:.78rem;color:var(--mint);font-family:var(--f-mono);">
            ✓ XUSDC stablecoin for stable settlements
          </div>
        </div>
      </div>
    </div>
  </section>

  <!-- ECONOMIC LOOP -->
  <section style="overflow:hidden;">
    <div class="container" style="text-align:center;">
      <span class="section-tag reveal">The Flywheel</span>
      <h2 class="section-title reveal">Self-<span>Reinforcing</span> Loop</h2>
      <p class="section-sub reveal" style="margin:0 auto;">The more it's used, the cheaper it gets. The cheaper it gets, the more it's used.</p>
      <div class="loop-flow reveal">
        <div class="loop-node"><div class="loop-icon-wrap">⚡</div><div class="loop-label">AI USAGE</div></div>
        <div class="loop-arrow">→</div>
        <div class="loop-node"><div class="loop-icon-wrap">💸</div><div class="loop-label">$XLAW SPENT</div></div>
        <div class="loop-arrow">→</div>
        <div class="loop-node"><div class="loop-icon-wrap">🔥</div><div class="loop-label">TOKEN BURN</div></div>
        <div class="loop-arrow">→</div>
        <div class="loop-node"><div class="loop-icon-wrap">📉</div><div class="loop-label">SCARCITY</div></div>
        <div class="loop-arrow">→</div>
        <div class="loop-node"><div class="loop-icon-wrap">🔧</div><div class="loop-label">NEW SKILLS</div></div>
        <div class="loop-arrow">→</div>
        <div class="loop-node"><div class="loop-icon-wrap">📈</div><div class="loop-label">EFFICIENCY</div></div>
        <div class="loop-arrow">↩</div>
      </div>
    </div>
  </section>

  <!-- TIERS -->
  <section id="tiers" style="background:var(--bg2);">
    <div class="container">
      <span class="section-tag reveal">Membership</span>
      <h2 class="section-title reveal">Choose Your <span>Secretary Tier</span></h2>
      <p class="section-sub reveal">Your Secretary NFT is your on-chain identity, reputation, and AI interface. It grows with you.</p>
      <div class="tiers-grid">
        <div class="tier-card reveal">
          <div class="tier-name">ASSOCIATE</div>
          <div class="tier-price">$49</div>
          <div class="tier-period">per month</div>
          <div class="tier-bonus">+50M $XLAW entry bonus</div>
          <ul class="tier-features">
            <li class="active">1 Secretary NFT</li>
            <li class="active">AI Secretary 24/7</li>
            <li class="active">Basic contract templates</li>
            <li class="active">Deadline reminders</li>
            <li>AI Compliance Agent</li>
            <li>Escrow deposits</li>
            <li>DAO voting</li>
          </ul>
          <button class="btn-tier" onclick="deployTier('ASSOCIATE','49')">Get Started</button>
        </div>
        <div class="tier-card featured reveal">
          <div class="tier-badge">POPULAR</div>
          <div class="tier-name">COUNSEL</div>
          <div class="tier-price">$99</div>
          <div class="tier-period">per month</div>
          <div class="tier-bonus">+150M $XLAW entry bonus</div>
          <ul class="tier-features">
            <li class="active">3 Secretary NFTs</li>
            <li class="active">AI Secretary 24/7</li>
            <li class="active">Advanced contract library</li>
            <li class="active">AI Compliance Agent</li>
            <li class="active">Escrow deposits</li>
            <li class="active">Priority arbitration</li>
            <li>DAO voting</li>
          </ul>
          <button class="btn-tier" onclick="deployTier('COUNSEL','99')">Get Started</button>
        </div>
        <div class="tier-card reveal">
          <div class="tier-name">PARTNER</div>
          <div class="tier-price">$199</div>
          <div class="tier-period">per month</div>
          <div class="tier-bonus">+350M $XLAW entry bonus</div>
          <ul class="tier-features">
            <li class="active">7 Secretary NFTs</li>
            <li class="active">All 5 AI Agents</li>
            <li class="active">Full contract library</li>
            <li class="active">AI Compliance Agent</li>
            <li class="active">Escrow deposits</li>
            <li class="active">DAO voting rights</li>
            <li class="active">Direct dev updates</li>
          </ul>
          <button class="btn-tier" onclick="deployTier('PARTNER','199')">Get Started</button>
        </div>
      </div>
    </div>
  </section>

  <!-- DEPLOY CTA -->
  <section class="cta-section">
    <div class="container">
      <span class="section-tag" style="display:block;">Deploy Now</span>
      <h2 class="section-title reveal">Your Agent. <span>Your Rules.</span><br>Your Chain.</h2>
      <p class="section-sub reveal" style="margin:0 auto 30px;">Connect your WebAuth wallet, choose a tier, deploy your AI agent on XPR Network.</p>
      <div class="cta-cards reveal">
        <div class="cta-mini"><div class="cta-mini-val">20 $XLAW</div><div class="cta-mini-label">ENTRY PRICE</div></div>
        <div class="cta-mini"><div class="cta-mini-val">+15 $XLAW</div><div class="cta-mini-label">CREDIT BONUS</div></div>
        <div class="cta-mini"><div class="cta-mini-val">12% APY</div><div class="cta-mini-label">STAKING YIELD</div></div>
        <div class="cta-mini"><div class="cta-mini-val">XPR</div><div class="cta-mini-label">NETWORK</div></div>
      </div>
      <div style="margin-top:36px;">
        <button class="btn-primary" onclick="openDeployModal()">Deploy Your Agent</button>
      </div>
    </div>
  </section>

  <!-- NETWORK STATUS -->
  <div class="network-bar">
    <div class="net-item"><span class="net-dot"></span>XPR MAINNET: ONLINE</div>
    <div class="net-item"><span class="net-dot"></span>CONTRACT: gcsctoken111</div>
    <div class="net-item"><span class="net-dot"></span>DEX: SimpleDEX ACTIVE</div>
    <div class="net-item"><span class="net-dot"></span>WEBAUTH: ENABLED</div>
    <div class="net-item"><span class="net-dot"></span>AGENTS: RUNNING</div>
  </div>
</div>
  `;
};

window.Pages.landingInit = function() {
  // Animated counters
  function animateCount(id, target) {
    const el = document.getElementById(id);
    if (!el) return;
    let start = 0;
    const step = target / 60;
    const timer = setInterval(() => {
      start = Math.min(start + step, target);
      el.textContent = Math.floor(start).toLocaleString();
      if (start >= target) clearInterval(timer);
    }, 30);
  }
  setTimeout(() => {
    animateCount('statAgents', 247);
    animateCount('statSkills', 1382);
    animateCount('statBurned', 8419234);
  }, 500);

  function updateBlock() {
    const el = document.getElementById('statBlock');
    if (el) el.textContent = ChainService.getBlockHeight().toLocaleString();
  }
  updateBlock();
  window._landingBlockInterval = setInterval(updateBlock, 3000);

  // Scroll reveals
  const revealEls = document.querySelectorAll('.reveal');
  const obs = new IntersectionObserver((entries) => {
    entries.forEach((e, i) => {
      if (e.isIntersecting) {
        setTimeout(() => e.target.classList.add('visible'), i * 50);
        obs.unobserve(e.target);
      }
    });
  }, { threshold: .12 });
  revealEls.forEach(el => obs.observe(el));
};

window.Pages.landingCleanup = function() {
  clearInterval(window._landingBlockInterval);
};
