// ═══════════════ SKILL MARKETPLACE PAGE ═══════════════
window.Pages = window.Pages || {};

let currentFilter = 'all';

window.Pages.marketplace = function() {
  return `
<div class="page marketplace-page">
  <div class="dash-greeting" style="margin-bottom:24px;">
    <h1>Skill Marketplace</h1>
    <p>Buy, sell, and publish AI workflows. 60% burn · 20% creator · 20% system.</p>
  </div>

  <div class="dash-grid">
    <div class="dash-card">
      <div class="dash-card-label">SKILLS AVAILABLE</div>
      <div class="dash-card-value accent">${MockData.skills.length}</div>
      <div class="dash-card-trend">+3 published today</div>
    </div>
    <div class="dash-card">
      <div class="dash-card-label">TOTAL USES</div>
      <div class="dash-card-value">${MockData.skills.reduce((s,k)=>s+k.uses,0).toLocaleString()}</div>
      <div class="dash-card-trend trend-up">▲ 12,450 this week</div>
    </div>
    <div class="dash-card">
      <div class="dash-card-label">AVG PRICE</div>
      <div class="dash-card-value">${Math.round(MockData.skills.reduce((s,k)=>s+k.price,0)/MockData.skills.length)} $XLAW</div>
      <div class="dash-card-trend">Per execution</div>
    </div>
    <div class="dash-card">
      <div class="dash-card-label">TOP CREATOR</div>
      <div class="dash-card-value" style="font-size:1.3rem;">builder.xpr</div>
      <div class="dash-card-trend mint">+4,892 $XLAW earned</div>
    </div>
  </div>

  <div class="market-filters" id="marketFilters">
    <div class="filter-btn ${currentFilter==='all'?'active':''}" onclick="filterSkills('all')">All</div>
    <div class="filter-btn ${currentFilter==='Construction'?'active':''}" onclick="filterSkills('Construction')">Construction</div>
    <div class="filter-btn ${currentFilter==='Legal'?'active':''}" onclick="filterSkills('Legal')">Legal</div>
    <div class="filter-btn ${currentFilter==='Risk'?'active':''}" onclick="filterSkills('Risk')">Risk</div>
    <div class="filter-btn ${currentFilter==='Real Estate'?'active':''}" onclick="filterSkills('Real Estate')">Real Estate</div>
    <div class="filter-btn ${currentFilter==='Trading'?'active':''}" onclick="filterSkills('Trading')">Trading</div>
    <div class="filter-btn ${currentFilter==='Compliance'?'active':''}" onclick="filterSkills('Compliance')">Compliance</div>
    <button class="btn-primary btn-sm" style="margin-left:auto;" onclick="publishSkill()">+ Publish Skill</button>
  </div>

  <div class="skill-grid" id="skillGrid">
    ${buildSkillGrid()}
  </div>

  <div class="bot-info-box" style="margin-top:22px;">
    <strong>How it works</strong>
    Skills are on-chain assets in the Skill Registry. When a user purchases a skill, 60% of the payment is burned (deflationary pressure), 20% goes to the skill creator, 20% to system ops. Skills are ranked by usage count, success rate, efficiency, and speed.
  </div>
</div>
  `;
};

function buildSkillGrid() {
  let skills = MockData.skills;
  if (currentFilter !== 'all') {
    skills = skills.filter(s => s.cat === currentFilter);
  }
  if (!skills.length) {
    return '<p style="color:var(--muted);text-align:center;padding:60px;grid-column:1/-1;">No skills in this category yet.</p>';
  }
  return skills.map(s => `
    <div class="skill-card" onclick="openSkill('${s.id}')">
      <div class="skill-cat">${s.cat.toUpperCase()}</div>
      <div class="skill-title">${s.title}</div>
      <div class="skill-desc">${s.desc}</div>
      <div class="skill-creator">
        <div class="creator-avatar"></div>
        <span>${s.creator}</span>
        <span class="skill-rating" style="margin-left:auto;">★ ${s.rating}</span>
      </div>
      <div class="skill-meta">
        <span class="skill-price">${s.price} $XLAW</span>
        <span class="skill-uses">${s.uses.toLocaleString()} uses</span>
      </div>
    </div>
  `).join('');
}

window.Pages.marketplaceInit = function() {};
window.Pages.marketplaceCleanup = function() {};

window.filterSkills = function(cat) {
  currentFilter = cat;
  document.querySelectorAll('#marketFilters .filter-btn').forEach(b => b.classList.remove('active'));
  event.currentTarget.classList.add('active');
  document.getElementById('skillGrid').innerHTML = buildSkillGrid();
};

window.openSkill = function(id) {
  const s = MockData.skills.find(x => x.id === id);
  if (!s) return;
  const content = `
    <div class="skill-cat">${s.cat.toUpperCase()}</div>
    <div class="modal-title">${s.title}</div>
    <div class="modal-sub">${s.desc}</div>
    <div style="display:grid;grid-template-columns:1fr 1fr;gap:10px;margin-bottom:16px;">
      <div style="background:rgba(139,92,246,0.08);border:1px solid var(--border);border-radius:10px;padding:10px;">
        <div style="font-size:.72rem;color:var(--muted);font-family:var(--f-mono);margin-bottom:3px;">PRICE</div>
        <div style="font-family:var(--f-display);font-weight:800;color:var(--lavender);">${s.price} $XLAW</div>
      </div>
      <div style="background:rgba(139,92,246,0.08);border:1px solid var(--border);border-radius:10px;padding:10px;">
        <div style="font-size:.72rem;color:var(--muted);font-family:var(--f-mono);margin-bottom:3px;">USES</div>
        <div style="font-family:var(--f-display);font-weight:800;">${s.uses.toLocaleString()}</div>
      </div>
      <div style="background:rgba(139,92,246,0.08);border:1px solid var(--border);border-radius:10px;padding:10px;">
        <div style="font-size:.72rem;color:var(--muted);font-family:var(--f-mono);margin-bottom:3px;">RATING</div>
        <div style="font-family:var(--f-display);font-weight:800;color:var(--gold);">★ ${s.rating}/5</div>
      </div>
      <div style="background:rgba(139,92,246,0.08);border:1px solid var(--border);border-radius:10px;padding:10px;">
        <div style="font-size:.72rem;color:var(--muted);font-family:var(--f-mono);margin-bottom:3px;">CREATOR</div>
        <div style="font-family:var(--f-mono);font-weight:700;font-size:.82rem;">${s.creator}</div>
      </div>
    </div>
    <div style="background:rgba(139,92,246,0.06);border:1px solid var(--border);border-radius:10px;padding:12px;margin-bottom:14px;font-size:.82rem;">
      <div style="color:var(--muted);font-family:var(--f-mono);font-size:.72rem;margin-bottom:6px;">DISTRIBUTION</div>
      <div style="display:flex;justify-content:space-between;margin-bottom:3px;"><span>🔥 Burn</span><span>60%</span></div>
      <div style="display:flex;justify-content:space-between;margin-bottom:3px;"><span>👤 Creator</span><span>20%</span></div>
      <div style="display:flex;justify-content:space-between;"><span>⚙️ System</span><span>20%</span></div>
    </div>
    <button class="btn-primary" style="width:100%;" onclick="purchaseSkill('${s.id}')">Purchase for ${s.price} $XLAW</button>
  `;
  document.getElementById('skillModalContent').innerHTML = content;
  document.getElementById('skillModal').classList.add('open');
};

window.purchaseSkill = async function(id) {
  const s = MockData.skills.find(x => x.id === id);
  if (!s) return;
  if (!WalletService.getState().connected) {
    closeModal('skillModal');
    showToast('Wallet Required', 'Connect your XPR wallet first.');
    openConnectModal();
    return;
  }
  if (MockData.user.xlawBalance < s.price) {
    showToast('Insufficient Balance', 'Not enough $XLAW.');
    return;
  }
  closeModal('skillModal');
  showToast('Purchasing...', `Signing transaction for ${s.title}`);
  try {
    const tx = await WalletService.sign('purchase_skill', { skill_id: id, amount: s.price });
    MockData.user.xlawBalance -= s.price;
    s.uses += 1;
    updateBalanceDisplay();
    showToast('✓ Skill Purchased', `${s.title} added to your skills · Tx: ${tx.txId.slice(0,10)}...`);
  } catch (e) {
    showToast('Error', e.message);
  }
};

window.publishSkill = function() {
  if (!WalletService.getState().connected) {
    showToast('Wallet Required', 'Connect your XPR wallet first.');
    openConnectModal();
    return;
  }
  showToast('Coming Soon', 'Skill publisher UI is under development. Skills are currently auto-generated after 3+ repeated tasks.');
};
