// ═══════════════ CHAT PAGE ═══════════════
window.Pages = window.Pages || {};

window.Pages.chat = function() {
  const threads = MockData.chatThreads;
  const active = threads[0];

  const sidebarHtml = threads.map((t, i) => `
    <div class="chat-thread ${i===0?'active':''}" onclick="switchThread('${t.id}','${t.abbr}','${t.name}')">
      <div class="thread-avatar">${t.abbr}</div>
      <div class="thread-info">
        <div class="thread-name">${t.name}</div>
        <div class="thread-last">${t.last}</div>
      </div>
    </div>
  `).join('');

  return `
<div class="page chat-page">
  <aside class="chat-sidebar">
    <div class="chat-sidebar-title">AGENTS</div>
    ${sidebarHtml}
    <div style="margin-top:24px;padding:12px;background:rgba(139,92,246,0.08);border:1px solid var(--border);border-radius:10px;font-size:.78rem;color:var(--muted);line-height:1.5;">
      <div style="font-family:var(--f-display);font-weight:700;color:var(--lavender);margin-bottom:4px;">Cost per message</div>
      ~0.3–0.8 $XLAW · 60% burned, 40% to ops
    </div>
  </aside>

  <div class="chat-main">
    <div class="chat-header">
      <div class="chat-avatar" id="chatAvatar">LDA</div>
      <div class="chat-head-info">
        <h3 id="chatHeadName">LDA Secretary</h3>
        <p>● Active · Last updated: just now</p>
      </div>
    </div>

    <div class="chat-messages" id="chatMessages">
      <div class="msg bot">
        <div class="msg-bubble">Hello, <strong>${MockData.user.name}</strong>. I'm your LDA Secretary — I handle all your legal document work on XPR Network.<br><br>How can I help you today?</div>
        <div class="msg-meta">LDA · just now</div>
      </div>
      <div class="msg bot">
        <div class="msg-bubble">I noticed Contract #4471 expires in 8 days. The contractor hasn't signed the completion certificate yet. Want me to take action?</div>
        <div class="msg-actions">
          <button class="msg-action" onclick="sendSuggestion('Send reminder to contractor')">Send reminder</button>
          <button class="msg-action" onclick="sendSuggestion('Open arbitration case')">Open arbitration case</button>
          <button class="msg-action" onclick="sendSuggestion('Extend contract by 14 days')">Extend 14 days</button>
        </div>
        <div class="msg-meta">LDA · 2 min ago</div>
      </div>
    </div>

    <div class="chat-input-wrap">
      <div class="chat-suggestions">
        <div class="chat-suggestion" onclick="sendSuggestion('Draft a new NDA contract')">+ Draft NDA</div>
        <div class="chat-suggestion" onclick="sendSuggestion('Show me all active contracts')">Active contracts</div>
        <div class="chat-suggestion" onclick="sendSuggestion('Analyze risk on Contract #4471')">Risk analysis</div>
        <div class="chat-suggestion" onclick="sendSuggestion('What are my deadlines this week?')">This week's deadlines</div>
      </div>
      <div class="chat-input-row">
        <textarea class="chat-input" id="chatInput" placeholder="Ask your AI secretary anything..." rows="1" onkeydown="handleChatKey(event)"></textarea>
        <button class="chat-send" id="chatSend" onclick="sendMessage()">Send →</button>
      </div>
    </div>
  </div>
</div>
  `;
};

window.Pages.chatInit = function() {
  // Auto-resize textarea
  const input = document.getElementById('chatInput');
  if (input) {
    input.addEventListener('input', () => {
      input.style.height = 'auto';
      input.style.height = Math.min(input.scrollHeight, 120) + 'px';
    });
  }
  // Scroll to bottom
  scrollChatToBottom();
};

window.Pages.chatCleanup = function() {};

window.handleChatKey = function(e) {
  if (e.key === 'Enter' && !e.shiftKey) {
    e.preventDefault();
    sendMessage();
  }
};

window.sendMessage = function() {
  const input = document.getElementById('chatInput');
  const text = input.value.trim();
  if (!text) return;
  appendMessage('user', text);
  input.value = '';
  input.style.height = 'auto';

  // Simulate typing indicator
  const messages = document.getElementById('chatMessages');
  const typingEl = document.createElement('div');
  typingEl.className = 'msg bot';
  typingEl.id = 'typingIndicator';
  typingEl.innerHTML = `<div class="msg-bubble" style="padding:0;"><div class="typing-indicator"><span></span><span></span><span></span></div></div>`;
  messages.appendChild(typingEl);
  scrollChatToBottom();

  // Generate response based on keywords
  setTimeout(() => {
    const typing = document.getElementById('typingIndicator');
    if (typing) typing.remove();
    const reply = generateBotReply(text);
    appendMessage('bot', reply.text, reply.actions);
  }, 1200 + Math.random() * 800);
};

window.sendSuggestion = function(text) {
  const input = document.getElementById('chatInput');
  input.value = text;
  sendMessage();
};

window.switchThread = function(id, abbr, name) {
  document.querySelectorAll('.chat-thread').forEach(t => t.classList.remove('active'));
  event.currentTarget.classList.add('active');
  document.getElementById('chatAvatar').textContent = abbr;
  document.getElementById('chatHeadName').textContent = name;
  document.getElementById('chatMessages').innerHTML = `
    <div class="msg bot">
      <div class="msg-bubble">Switched to <strong>${name}</strong>. How can I help you?</div>
      <div class="msg-meta">${abbr} · just now</div>
    </div>
  `;
};

function appendMessage(role, text, actions = null) {
  const messages = document.getElementById('chatMessages');
  if (!messages) return;
  const el = document.createElement('div');
  el.className = 'msg ' + role;
  const actionsHtml = actions ? `<div class="msg-actions">${actions.map(a => `<button class="msg-action" onclick="sendSuggestion('${a.replace(/'/g,"\\'")}')">${a}</button>`).join('')}</div>` : '';
  el.innerHTML = `
    <div class="msg-bubble">${text.replace(/\n/g, '<br>')}</div>
    ${actionsHtml}
    <div class="msg-meta">${role === 'user' ? 'You' : 'LDA'} · just now</div>
  `;
  messages.appendChild(el);
  scrollChatToBottom();
}

function generateBotReply(userText) {
  const lower = userText.toLowerCase();
  if (lower.includes('contract') || lower.includes('draft') || lower.includes('nda')) {
    return {
      text: "I'll draft that contract now. Based on your past contracts, I'll use your standard template with these adjustments:\n\n• 60-day term\n• Milestone-based payments\n• Escrow via EFA agent\n• Compliance check via KYC-A\n\nEstimated cost: 1.2 $XLAW. Ready to proceed?",
      actions: ['Yes, generate now', 'Show me template first', 'Cancel']
    };
  }
  if (lower.includes('deadline') || lower.includes('week')) {
    return {
      text: "Here are your 3 pending deadlines this week:\n\n• <strong>Contract #4471</strong> — Oct 22 (expires)\n• <strong>Escrow release #8921</strong> — Oct 24 ($15K)\n• <strong>License renewal</strong> — Oct 26\n\nWant me to send reminders to all counterparties?",
      actions: ['Send all reminders', 'Show details', 'Not now']
    };
  }
  if (lower.includes('risk')) {
    return {
      text: "Risk Analysis for Contract #4471:\n\n• Counterparty score: <strong>72/100</strong> (good)\n• Jurisdiction: compliant (California)\n• Historical dispute rate: 2.1%\n• Payment delay history: 0\n\nRecommendation: Proceed with standard escrow terms. Low risk profile.",
      actions: ['Apply standard terms', 'Increase escrow', 'Full report']
    };
  }
  if (lower.includes('reminder') || lower.includes('send')) {
    return {
      text: "Done. Reminder sent to contractor via WebAuth-signed message. They have been asked to sign the completion certificate within 48 hours.\n\nTransaction: <code>0xa3f2...e891</code>\nCost: 0.4 $XLAW (60% burned)",
      actions: null
    };
  }
  if (lower.includes('active') || lower.includes('show')) {
    return {
      text: "You have <strong>4 active contracts</strong>:\n\n• #4471 — Construction (expires 8d)\n• #4490 — NDA with Acme Corp\n• #4512 — Service agreement\n• #4531 — Partnership deal\n\nTotal value: $847,200 · 2 require action this week.",
      actions: ['View all', 'Export as PDF', 'Filter active']
    };
  }
  if (lower.includes('arbitration') || lower.includes('dispute')) {
    return {
      text: "Opening dispute case via DAA agent. Proposed resolution path:\n\n1. Freeze escrow funds\n2. Notify both parties (48h response)\n3. DAO vote if no resolution\n\nCost: 2.0 $XLAW filing fee. 50% burned, 50% to Treasury. Proceed?",
      actions: ['Open case now', 'Try negotiation first', 'Cancel']
    };
  }
  if (lower.includes('extend')) {
    return {
      text: "I'll extend Contract #4471 by 14 days. New expiry: Nov 5.\n\nThis requires:\n• Counterparty signature\n• 0.3 $XLAW fee\n• On-chain update via gcsctoken111\n\nSend extension request?",
      actions: ['Yes, send request', 'Change terms first', 'Cancel']
    };
  }
  // Default
  const defaults = MockData.chatResponses.default;
  return { text: defaults[Math.floor(Math.random()*defaults.length)], actions: null };
}

function scrollChatToBottom() {
  const messages = document.getElementById('chatMessages');
  if (messages) messages.scrollTop = messages.scrollHeight;
}
