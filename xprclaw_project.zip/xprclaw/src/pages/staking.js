// ═══════════════ STAKING PAGE ═══════════════
window.Pages = window.Pages || {};

window.Pages.staking = function() {
  const u = MockData.user;
  const positions = MockData.stakePositions;
  const totalStaked = positions.reduce((s, p) => s + p.amount, 0);
  const totalEarned = positions.reduce((s, p) => s + p.earned, 0);

  const positionsHtml = positions.length ? positions.map(p => `
    <div class="position-item">
      <div>
        <div class="pos-label">STAKED</div>
        <div class="pos-value accent">${p.amount.toLocaleString()} $XLAW</div>
      </div>
      <div>
        <div class="pos-label">EARNED</div>
        <div class="pos-value mint">+${p.earned.toFixed(2)} $XLAW</div>
      </div>
      <div>
        <div class="pos-label">UNLOCK</div>
        <div class="pos-value">${p.unlockOn}</div>
      </div>
      <div>
        <button class="btn-secondary btn-sm" onclick="claimRewards('${p.id}')">Claim</button>
      </div>
    </div>
  `).join('') : `<p style="color:var(--muted);text-align:center;padding:30px;">No active stakes. Start earning 12% APY.</p>`;

  return `
<div class="page staking-page">
  <div class="dash-greeting" style="margin-bottom:24px;">
    <h1>Staking</h1>
    <p>Lock your $XLAW for 30 days and earn yield from platform revenue.</p>
  </div>

  <div class="stake-hero">
    <div class="stake-hero-label">CURRENT APY</div>
    <div class="stake-hero-apy">12%</div>
    <div class="stake-hero-sub">30-day lock · Rewards from 30% of subscription + insurance revenue</div>
    <div style="margin-top:22px;position:relative;z-index:1;">
      <button class="btn-primary" onclick="openStakeModal()">+ Stake $XLAW</button>
    </div>
  </div>

  <div class="stake-grid">
    <div class="dash-card">
      <div class="dash-card-label">TOTAL STAKED</div>
      <div class="dash-card-value accent">${totalStaked.toLocaleString()}</div>
      <div class="dash-card-trend">$XLAW locked</div>
    </div>
    <div class="dash-card">
      <div class="dash-card-label">TOTAL EARNED</div>
      <div class="dash-card-value mint">+${totalEarned.toFixed(2)}</div>
      <div class="dash-card-trend">$XLAW lifetime rewards</div>
    </div>
    <div class="dash-card">
      <div class="dash-card-label">DAILY REWARD</div>
      <div class="dash-card-value">${(totalStaked * 0.12 / 365).toFixed(2)}</div>
      <div class="dash-card-trend">$XLAW/day estimated</div>
    </div>
    <div class="dash-card">
      <div class="dash-card-label">ACTIVE POSITIONS</div>
      <div class="dash-card-value">${positions.length}</div>
      <div class="dash-card-trend">Max: unlimited</div>
    </div>
  </div>

  <div class="stake-positions">
    <div class="dash-panel-header">
      <div class="dash-panel-title">Your Staking Positions</div>
      <div class="dash-panel-sub">Contract: gcscstake111</div>
    </div>
    ${positionsHtml}
  </div>

  <div class="bot-info-box" style="margin-top:18px;">
    <strong>How staking works</strong>
    Stakers receive 30% of platform subscription revenue + 30% of insurance premiums, distributed proportionally. Rewards compound daily. Lock period is 30 days minimum — early unlock incurs a 10% penalty. All distributions happen on-chain via <code>gcscstake111</code>.
  </div>
</div>
  `;
};

window.Pages.stakingInit = function() {};
window.Pages.stakingCleanup = function() {};

window.openStakeModal = function() {
  if (!WalletService.getState().connected) {
    showToast('Wallet Required', 'Connect your XPR wallet first.');
    openConnectModal();
    return;
  }
  document.getElementById('stakeBal').textContent = MockData.user.xlawBalance.toLocaleString();
  const input = document.getElementById('stakeAmount');
  input.value = '';
  input.oninput = () => {
    const amt = parseFloat(input.value) || 0;
    const reward = (amt * 0.12 / 365) * 30;
    document.getElementById('stakeReward').textContent = reward.toFixed(2) + ' $XLAW';
    const d = new Date();
    d.setDate(d.getDate() + 30);
    document.getElementById('stakeUnlock').textContent = d.toLocaleDateString('en-US', { month: 'short', day: 'numeric', year: 'numeric' });
  };
  document.getElementById('stakeModal').classList.add('open');
};

window.executeStake = async function() {
  const amt = parseFloat(document.getElementById('stakeAmount').value) || 0;
  if (amt <= 0) {
    showToast('Invalid Amount', 'Enter an amount greater than zero.');
    return;
  }
  if (amt > MockData.user.xlawBalance) {
    showToast('Insufficient Balance', 'You do not have enough $XLAW.');
    return;
  }
  closeModal('stakeModal');
  showToast('Signing...', 'Please approve the transaction in your wallet.');
  try {
    const tx = await WalletService.sign('stake', { amount: amt, lock_days: 30 });
    showToast('✓ Stake Confirmed', `${amt.toLocaleString()} $XLAW staked · Tx: ${tx.txId.slice(0,10)}...`);
    // Update mock
    MockData.user.xlawBalance -= amt;
    MockData.user.stakedAmount += amt;
    const d = new Date();
    const unlock = new Date(); unlock.setDate(d.getDate() + 30);
    MockData.stakePositions.push({
      id: 'sp' + Date.now(),
      amount: amt,
      lockedOn: d.toISOString().slice(0,10),
      unlockOn: unlock.toISOString().slice(0,10),
      apy: 12, earned: 0, status: 'active',
    });
    updateBalanceDisplay();
    navigate('staking');
  } catch (e) {
    showToast('Error', e.message);
  }
};

window.claimRewards = async function(id) {
  const pos = MockData.stakePositions.find(p => p.id === id);
  if (!pos) return;
  showToast('Claiming...', `Claiming ${pos.earned.toFixed(2)} $XLAW rewards`);
  try {
    await WalletService.sign('claim', { position_id: id });
    MockData.user.xlawBalance += pos.earned;
    showToast('✓ Claimed', `+${pos.earned.toFixed(2)} $XLAW added to your balance`);
    pos.earned = 0;
    updateBalanceDisplay();
    navigate('staking');
  } catch (e) {
    showToast('Error', e.message);
  }
};
