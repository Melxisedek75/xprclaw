// ═══════════════════════════════════════════════════════════════
// Mock Data — GCSC CLAW
// In production, this data comes from XPR Network blockchain
// and the Python trading bot backend (see backend/trading-bot/)
// ═══════════════════════════════════════════════════════════════

window.MockData = {

  // ─── USER ──────────────────────────────────────────────────
  user: {
    name: 'Builder',
    wallet: 'gcscdao.xpr',
    tier: 'COUNSEL',
    xlawBalance: 12500,
    xusdcBalance: 340.50,
    stakedAmount: 5000,
    memberSince: '2025-01-15',
    reputation: 87,
  },

  // ─── AGENTS ────────────────────────────────────────────────
  agents: [
    { id:'a1', name:'ConstructionOne',   type:'LDA',   status:'active',    lastRun:'2 min ago',  skills:12, executions:847 },
    { id:'a2', name:'LegalAssistant',    type:'DAA',   status:'active',    lastRun:'5 min ago',  skills:8,  executions:423 },
    { id:'a3', name:'ComplianceAgent',   type:'KYC-A', status:'idle',      lastRun:'1 hr ago',   skills:5,  executions:156 },
    { id:'a4', name:'EscrowManager',     type:'EFA',   status:'active',    lastRun:'12 min ago', skills:7,  executions:289 },
  ],

  // ─── ACTIVITY FEED ─────────────────────────────────────────
  activity: [
    { icon:'⚡', title:'Contract #4471 drafted by LDA agent',      meta:'2 min ago · 0.5 $XLAW burned',  value:'-0.5', type:'spend' },
    { icon:'🔥', title:'Skill "Cost Estimator v3" created',         meta:'8 min ago · auto-generated',     value:'+20',  type:'earn' },
    { icon:'💸', title:'Staking rewards claimed',                    meta:'14 min ago · 30-day cycle',      value:'+50',  type:'earn' },
    { icon:'🏪', title:'Skill "Risk Score Pro" purchased by user',   meta:'32 min ago · marketplace',       value:'+12',  type:'earn' },
    { icon:'⚖️', title:'Dispute #892 resolved by DAA agent',         meta:'1 hr ago · DAO vote',            value:'-2.0', type:'spend' },
    { icon:'🔐', title:'Escrow deposit confirmed',                    meta:'2 hr ago · $15,000 USDC',        value:'-0.3', type:'spend' },
    { icon:'✓',  title:'KYC verification complete for client',       meta:'3 hr ago · WebAuth + NFC',       value:'-1.0', type:'spend' },
    { icon:'📊', title:'Contractor matching report generated',       meta:'4 hr ago · CMA + REA',           value:'-0.8', type:'spend' },
  ],

  // ─── CHAT THREADS ──────────────────────────────────────────
  chatThreads: [
    { id:'t1', name:'LDA Secretary',  abbr:'LDA',   last:'Contract #4471 is ready for review' },
    { id:'t2', name:'DAA Arbitrator', abbr:'DAA',   last:'Dispute resolution — waiting for vote' },
    { id:'t3', name:'KYC Compliance', abbr:'KYC',   last:'All licenses verified successfully' },
    { id:'t4', name:'EFA Escrow',     abbr:'EFA',   last:'Escrow released to contractor' },
    { id:'t5', name:'REA Regulatory', abbr:'REA',   last:'New regulation detected in CA' },
  ],

  // ─── SKILLS MARKETPLACE ────────────────────────────────────
  skills: [
    { id:'sk1', cat:'Construction', title:'Cost Estimator Pro',         desc:'Auto-generates detailed cost breakdowns from project scope. Trained on 2,400+ projects.', price:15, uses:1842, creator:'builder.xpr',       rating:4.9 },
    { id:'sk2', cat:'Legal',        title:'Contract Drafter v4',        desc:'Multi-jurisdiction contract generator with automatic compliance checks.', price:25, uses:923, creator:'legalpro.xpr',      rating:4.8 },
    { id:'sk3', cat:'Risk',         title:'Risk Score ML',              desc:'Machine learning risk assessment for counterparties and contracts.', price:12, uses:2156, creator:'riskguru.xpr',      rating:4.7 },
    { id:'sk4', cat:'Real Estate',  title:'Property Valuator',          desc:'Instant property valuation using comparables, trends, and AI analysis.', price:20, uses:687, creator:'realproplus.xpr',    rating:4.9 },
    { id:'sk5', cat:'Trading',      title:'Trend Detector',             desc:'Identifies trending vs ranging market regimes using HMM classifier.', price:30, uses:445, creator:'quantdao.xpr',      rating:4.6 },
    { id:'sk6', cat:'Trading',      title:'News Impact Analyzer',       desc:'Filters market-moving news from noise using LLM-based classification.', price:35, uses:312, creator:'newsalpha.xpr',     rating:4.8 },
    { id:'sk7', cat:'Compliance',   title:'License Verifier',           desc:'Real-time contractor license verification across all 50 US states.', price:8, uses:4210, creator:'compliancehub.xpr', rating:4.9 },
    { id:'sk8', cat:'Construction', title:'Contractor Matcher',         desc:'NLP + geo-matching to find best contractors for specific project types.', price:18, uses:1067, creator:'buildconnect.xpr',  rating:4.7 },
    { id:'sk9', cat:'Legal',        title:'Dispute Analyzer',           desc:'Predicts dispute outcomes based on historical DAO arbitration data.', price:22, uses:564, creator:'arbitrate.xpr',     rating:4.8 },
  ],

  // ─── STAKING POSITIONS ─────────────────────────────────────
  stakePositions: [
    { id:'sp1', amount:3000, lockedOn:'2025-08-20', unlockOn:'2025-09-19', apy:12, earned:87.45, status:'active' },
    { id:'sp2', amount:2000, lockedOn:'2025-09-01', unlockOn:'2025-10-01', apy:12, earned:42.30, status:'active' },
  ],

  // ─── TRADING BOT (mock data that simulates backend) ────────
  trading: {
    status: 'running', // running | paused | stopped
    mode: 'trend-following',
    pair: 'BTC/USDT',
    balance: 10000,
    equity: 10834.52,
    dayPnl: 234.12,
    totalPnl: 834.52,
    winRate: 62.5,
    sharpe: 1.43,
    maxDrawdown: -4.2,
    openPositions: [
      { pair:'BTC/USDT', side:'long',  entry:62340, current:62890, size:0.05, pnl:27.50,  pnlPct:0.88 },
      { pair:'ETH/USDT', side:'long',  entry:2445,  current:2478,  size:0.8,  pnl:26.40,  pnlPct:1.35 },
      { pair:'SOL/USDT', side:'short', entry:145.2, current:142.8, size:10,   pnl:24.00,  pnlPct:1.65 },
    ],
    recentSignals: [
      { type:'buy',  pair:'BTC/USDT', time:'2m ago',  body:'Trend module: breakout above VWAP confirmed. Strength 0.74 (calibrated).' },
      { type:'hold', pair:'ETH/USDT', time:'5m ago',  body:'Regime detector: trending. Context agent: no risk flags. Holding position.' },
      { type:'sell', pair:'DOGE/USDT',time:'12m ago', body:'Mean-reversion module: RSI extreme reached 78. Exit signal. Strength 0.68.' },
      { type:'hold', pair:'SOL/USDT', time:'18m ago', body:'Short position performing. Trailing stop adjusted to -142.5.' },
      { type:'buy',  pair:'LINK/USDT',time:'25m ago', body:'News agent: bullish partnership announcement. Event-driven entry. Strength 0.81.' },
    ],
    // Simulated price history for chart (last 60 points)
    priceHistory: (() => {
      const pts = []; let p = 62000;
      for (let i = 0; i < 60; i++) {
        p += (Math.random() - 0.48) * 150;
        pts.push(Math.round(p));
      }
      return pts;
    })(),
    // Equity curve (30 points)
    equityCurve: (() => {
      const pts = []; let v = 10000;
      for (let i = 0; i < 30; i++) {
        v += (Math.random() - 0.35) * 80;
        pts.push(Math.round(v * 100) / 100);
      }
      return pts;
    })(),
  },

  // ─── AGENT CHAT SAMPLE RESPONSES ───────────────────────────
  chatResponses: {
    default: [
      "I've reviewed the request. Based on your active contracts, I recommend proceeding with caution.",
      "Analyzing the context now. Your reputation score supports this transaction.",
      "Done. I've logged this to your on-chain history. 0.5 $XLAW burned per execution.",
      "I found 3 relevant skills in the marketplace that could handle this automatically. Shall I apply them?",
    ],
    contract: [
      "Contract draft is ready. Key terms: 60-day term, milestone-based payments, escrow via EFA agent.\n\nEstimated cost: 1.2 $XLAW to finalize on-chain.",
      "I've identified 2 compliance issues in the counterparty's profile. Want me to request additional verification via KYC-A?",
    ],
    reminder: [
      "Contract #4471 expires in 8 days. The contractor has not yet signed the completion certificate.\n\nOptions:",
      "You have 3 pending deadlines this week:\n• Contract #4471 — Oct 22\n• Escrow release #8921 — Oct 24\n• License renewal — Oct 26",
    ],
    risk: [
      "Risk Analysis Complete:\n\n• Counterparty score: 72/100 (good)\n• Jurisdiction: compliant\n• Historical dispute rate: 2.1%\n\nRecommendation: Proceed with standard escrow terms.",
    ],
  },

};
